import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Copy, Check, ArrowRight, Users, KeyRound, Settings, LogOut, Play } from 'lucide-react';
import { drawMainMenuScene } from '../game/pixelRenderer.ts';
import { soundFX } from '../game/audio.ts';
import { VIEW_HEIGHT, VIEW_WIDTH } from '../shared/levelData.ts';

interface MainMenuProps {
  onStartLocal: () => void;
  onCreateOnlineRoom: (playerName: string) => void;
  onJoinOnlineRoom: (code: string, playerName: string) => void;
  onExit: () => void;
  onlineBusy: boolean;
  onlineError: string | null;
  clearOnlineError: () => void;
  scanlines: boolean;
  setScanlines: (v: boolean) => void;
}

type MenuPanel = 'main' | 'coop' | 'settings';

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartLocal,
  onCreateOnlineRoom,
  onJoinOnlineRoom,
  onExit,
  onlineBusy,
  onlineError,
  clearOnlineError,
  scanlines,
  setScanlines,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [panel, setPanel] = useState<MenuPanel>('main');
  const [coopTab, setCoopTab] = useState<'choose' | 'join'>('choose');
  const [joinCode, setJoinCode] = useState('');
  const [playerName, setPlayerName] = useState('');
  const [muted, setMuted] = useState(soundFX.isMuted());
  const [musicVol, setMusicVol] = useState(soundFX.getVolumes().musicVolume);
  const [sfxVol, setSfxVol] = useState(soundFX.getVolumes().sfxVolume);
  const [copiedHint, setCopiedHint] = useState(false);

  useEffect(() => {
    let rafId = 0;
    const render = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          drawMainMenuScene(ctx, performance.now());
        }
      }
      rafId = requestAnimationFrame(render);
    };
    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, []);

  const wakeAudio = () => {
    soundFX.startAmbientMusic();
  };

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundFX.setMuted(next);
    if (!next) {
      soundFX.startAmbientMusic();
      soundFX.menuClick();
    }
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    wakeAudio();
    soundFX.menuClick();
    if (!joinCode.trim()) return;
    onJoinOnlineRoom(joinCode.trim().toUpperCase(), playerName.trim());
  };

  const handleCreateClick = () => {
    wakeAudio();
    soundFX.menuClick();
    onCreateOnlineRoom(playerName.trim());
  };

  return (
    <div
      className="relative w-full h-full flex flex-col items-center justify-between py-6 sm:py-10 px-4 overflow-y-auto"
      onClick={wakeAudio}
    >
      {/* Live Pixel Art Cave Canvas Background */}
      <canvas
        ref={canvasRef}
        width={VIEW_WIDTH}
        height={VIEW_HEIGHT}
        className="pixel-canvas absolute inset-0 w-full h-full object-cover pointer-events-none"
      />

      {/* Top Audio Control */}
      <div className="relative z-10 w-full max-w-4xl flex items-center justify-between">
        <div className="text-xs text-[#b5aa99] tracking-wide">
          كهوف طاسيلي الأثرية · تجربة تعاونية
        </div>
        <button
          type="button"
          onClick={toggleMute}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-[#ede4d3] bg-[#0e131e]/85 border border-[#4a3e30] hover:border-[#e5a93c] transition-colors cursor-pointer"
          aria-label={muted ? 'تشغيل الصوت' : 'كتم الصوت'}
        >
          {muted ? <VolumeX className="w-4 h-4 text-[#d44848]" /> : <Volume2 className="w-4 h-4 text-[#e5a93c]" />}
          <span className="whitespace-nowrap">{muted ? 'صامت' : 'الصوت مفعل'}</span>
        </button>
      </div>

      {/* Center Ornate Game Title & Vertical Menu */}
      <div className="relative z-10 w-full max-w-lg flex flex-col items-center my-auto py-4">
        {/* Title Crest */}
        <div className="w-full flex flex-col items-center mb-7">
          <div className="relative px-8 py-4 border border-[#5c4c38] bg-[#0b0e17]/88 shadow-2xl text-center w-full max-w-md">
            <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-24 h-1 bg-[#e5a93c]" />
            <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-24 h-1 bg-[#60cde6]" />
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-[#f4ead5] tracking-normal leading-tight drop-shadow-[0_3px_10px_rgba(0,0,0,0.9)]">
              ما خفي أعظم
            </h1>
            <p className="mt-1.5 text-xs sm:text-sm text-[#c7b38b]">
              رحلة الصديقين في أعماق طاسيلي
            </p>
          </div>
        </div>

        {/* Main Vertical Menu */}
        {panel === 'main' && (
          <nav className="w-full max-w-xs flex flex-col gap-3" aria-label="القائمة الرئيسية">
            <button
              type="button"
              onMouseEnter={() => soundFX.menuHover()}
              onClick={() => {
                wakeAudio();
                soundFX.menuClick();
                onStartLocal();
              }}
              className="group relative w-full py-3 px-5 bg-[#121723]/92 border border-[#4a3f33] hover:border-[#e5a93c] hover:bg-[#192030] text-[#f5ebd6] font-bold text-base sm:text-lg transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <Play className="w-4 h-4 text-[#e5a93c] opacity-80 group-hover:opacity-100" />
              <span className="whitespace-nowrap">لعبة جديدة</span>
            </button>

            <button
              type="button"
              onMouseEnter={() => soundFX.menuHover()}
              onClick={() => {
                wakeAudio();
                soundFX.menuClick();
                clearOnlineError();
                setPanel('coop');
                setCoopTab('choose');
              }}
              className="group relative w-full py-3 px-5 bg-[#121723]/92 border border-[#4a3f33] hover:border-[#60cde6] hover:bg-[#192030] text-[#f5ebd6] font-bold text-base sm:text-lg transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <Users className="w-4 h-4 text-[#60cde6] opacity-80 group-hover:opacity-100" />
              <span className="whitespace-nowrap">اللعب التعاوني أونلاين</span>
            </button>

            <button
              type="button"
              onMouseEnter={() => soundFX.menuHover()}
              onClick={() => {
                wakeAudio();
                soundFX.menuClick();
                setPanel('settings');
              }}
              className="group relative w-full py-3 px-5 bg-[#121723]/92 border border-[#3a332b] hover:border-[#e5a93c] hover:bg-[#192030] text-[#ddd2be] font-semibold text-base transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <Settings className="w-4 h-4 text-[#b8a586]" />
              <span className="whitespace-nowrap">الإعدادات</span>
            </button>

            <button
              type="button"
              onMouseEnter={() => soundFX.menuHover()}
              onClick={() => {
                soundFX.menuClick();
                onExit();
              }}
              className="group relative w-full py-3 px-5 bg-[#10131d]/90 border border-[#352b2a] hover:border-[#d44848] hover:bg-[#1c1619] text-[#c7b9a5] hover:text-[#f2c4c4] font-semibold text-base transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <LogOut className="w-4 h-4 text-[#c46363]" />
              <span className="whitespace-nowrap">الخروج</span>
            </button>
          </nav>
        )}

        {/* Online Co-op Panel (Create Room & Join with Code) */}
        {panel === 'coop' && (
          <div className="w-full max-w-md bg-[#0e131e]/95 border border-[#4d4234] p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#2c2f3b]">
              <h2 className="text-lg font-bold text-[#f4ead5] flex items-center gap-2">
                <Users className="w-5 h-5 text-[#60cde6]" />
                <span>اللعب التعاوني أونلاين</span>
              </h2>
              <button
                type="button"
                onClick={() => {
                  soundFX.menuClick();
                  clearOnlineError();
                  setPanel('main');
                }}
                className="flex items-center gap-1.5 text-xs text-[#bfb29b] hover:text-[#f4ead5] px-2.5 py-1 border border-[#323645] hover:border-[#60cde6] transition-colors cursor-pointer"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>رجوع</span>
              </button>
            </div>

            {/* Explorer Name Optional Input */}
            <div className="mb-4">
              <label htmlFor="explorer-name" className="block text-xs text-[#bfb29b] mb-1.5">
                اسم المستكشف (اختياري)
              </label>
              <input
                id="explorer-name"
                type="text"
                maxLength={18}
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="مثال: سيف أو طارق"
                className="w-full px-3 py-2 bg-[#080b12] border border-[#363a47] focus:border-[#e5a93c] outline-none text-sm text-[#f4ead5] placeholder:text-[#666c7c]"
              />
            </div>

            {onlineError && (
              <div className="mb-4 p-3 bg-[#2a1418] border border-[#a8383b] text-xs text-[#f8c8c8]">
                {onlineError}
              </div>
            )}

            {coopTab === 'choose' ? (
              <div className="flex flex-col gap-3">
                <button
                  type="button"
                  disabled={onlineBusy}
                  onClick={handleCreateClick}
                  className="w-full py-3.5 px-4 bg-[#172130] border border-[#e5a93c]/70 hover:border-[#e5a93c] hover:bg-[#1e2a3d] text-[#f7edd9] font-bold text-base transition-all flex items-center justify-between cursor-pointer disabled:opacity-50"
                >
                  <span className="flex items-center gap-2.5">
                    <KeyRound className="w-4 h-4 text-[#e5a93c]" />
                    <span>إنشاء غرفة (Create Room)</span>
                  </span>
                  <span className="text-xs text-[#e5a93c]">توليد رمز ودعوة صديق</span>
                </button>

                <button
                  type="button"
                  disabled={onlineBusy}
                  onClick={() => {
                    soundFX.menuClick();
                    clearOnlineError();
                    setCoopTab('join');
                  }}
                  className="w-full py-3.5 px-4 bg-[#131a26] border border-[#60cde6]/60 hover:border-[#60cde6] hover:bg-[#192434] text-[#f7edd9] font-bold text-base transition-all flex items-center justify-between cursor-pointer disabled:opacity-50"
                >
                  <span className="flex items-center gap-2.5">
                    <Users className="w-4 h-4 text-[#60cde6]" />
                    <span>انضمام برمز (Join with Code)</span>
                  </span>
                  <span className="text-xs text-[#60cde6]">أدخل رمز صديقك</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleJoinSubmit} className="flex flex-col gap-3">
                <div>
                  <label htmlFor="room-code-input" className="block text-xs text-[#c7b38b] mb-1.5">
                    أدخل كود الغرفة للانضمام الفوري لصديقك
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="room-code-input"
                      type="text"
                      value={joinCode}
                      onChange={(e) => {
                        clearOnlineError();
                        setJoinCode(e.target.value.toUpperCase());
                      }}
                      placeholder="مثال: TSL492"
                      dir="ltr"
                      maxLength={10}
                      autoFocus
                      className="flex-1 px-3.5 py-2.5 bg-[#080b12] border border-[#4c5468] focus:border-[#60cde6] outline-none text-base font-mono-nums tracking-widest text-center text-[#f4ead5] uppercase"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.readText?.().then((txt) => {
                          if (txt) {
                            setJoinCode(txt.trim().toUpperCase().slice(0, 10));
                            setCopiedHint(true);
                            setTimeout(() => setCopiedHint(false), 1200);
                          }
                        }).catch(() => {});
                      }}
                      className="px-3 py-2 bg-[#141a26] border border-[#3b4152] hover:border-[#60cde6] text-xs text-[#c4ccd9] cursor-pointer"
                      title="لصق الرمز"
                    >
                      {copiedHint ? <Check className="w-4 h-4 text-[#60cde6]" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={onlineBusy || !joinCode.trim()}
                    className="flex-1 py-2.5 px-4 bg-[#1c2f3b] border border-[#60cde6] hover:bg-[#233b4a] text-[#eef8fc] font-bold text-sm transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {onlineBusy ? 'جاري الاتصال...' : 'دخول الغرفة الآن'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      soundFX.menuClick();
                      setCoopTab('choose');
                    }}
                    className="px-4 py-2.5 bg-[#121621] border border-[#3a3e4c] hover:border-[#e5a93c] text-sm text-[#c7b9a5] cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Settings Panel */}
        {panel === 'settings' && (
          <div className="w-full max-w-md bg-[#0e131e]/95 border border-[#4d4234] p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#2c2f3b]">
              <h2 className="text-lg font-bold text-[#f4ead5] flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#e5a93c]" />
                <span>الإعدادات والتحكم</span>
              </h2>
              <button
                type="button"
                onClick={() => {
                  soundFX.menuClick();
                  setPanel('main');
                }}
                className="flex items-center gap-1.5 text-xs text-[#bfb29b] hover:text-[#f4ead5] px-2.5 py-1 border border-[#323645] hover:border-[#e5a93c] transition-colors cursor-pointer"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>رجوع</span>
              </button>
            </div>

            <div className="space-y-4 text-sm">
              <div>
                <div className="flex justify-between text-xs text-[#c7b38b] mb-1">
                  <span>موسيقى الكهف</span>
                  <span className="font-mono-nums">{Math.round(musicVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={musicVol}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    setMusicVol(v);
                    soundFX.setMusicVolume(v);
                  }}
                  className="w-full accent-[#e5a93c]"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-[#c7b38b] mb-1">
                  <span>المؤثرات الصوتية</span>
                  <span className="font-mono-nums">{Math.round(sfxVol * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={sfxVol}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    setSfxVol(v);
                    soundFX.setSfxVolume(v);
                  }}
                  className="w-full accent-[#60cde6]"
                />
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-[#262b38]">
                <span className="text-xs text-[#ddd2be]">خطوط الشاشة الكلاسيكية (Scanlines)</span>
                <button
                  type="button"
                  onClick={() => {
                    soundFX.menuClick();
                    setScanlines(!scanlines);
                  }}
                  className={`px-3 py-1 text-xs font-semibold border transition-colors cursor-pointer ${
                    scanlines
                      ? 'bg-[#1c2b35] border-[#60cde6] text-[#eef8fc]'
                      : 'bg-[#141822] border-[#3a3f4d] text-[#9aa1b2]'
                  }`}
                >
                  {scanlines ? 'مفعل' : 'معطل'}
                </button>
              </div>

              <div className="pt-3 border-t border-[#262b38] text-xs text-[#b7ae9c] space-y-1.5">
                <div className="font-bold text-[#e5a93c]">مفاتيح اللعب:</div>
                <div className="flex justify-between">
                  <span>الحركة والقفز:</span>
                  <span className="font-mono-nums text-[#ede4d3]">A / D + W أو الأسهم</span>
                </div>
                <div className="flex justify-between">
                  <span>التفاعل (رافعة / مفتاح / طبق):</span>
                  <span className="font-mono-nums text-[#ede4d3]">E</span>
                </div>
                <div className="flex justify-between">
                  <span>ضربة الخنجر / شفاء بالروح:</span>
                  <span className="font-mono-nums text-[#ede4d3]">F للضرب · Q للشفاء</span>
                </div>
                <div className="flex justify-between">
                  <span>إشارات سريعة / تبديل محلي:</span>
                  <span className="font-mono-nums text-[#ede4d3]">1-4 · Tab للتبديل</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom subtle hint */}
      <div className="relative z-10 text-xs text-[#9e9482] text-center">
        اختر «لعبة جديدة» للتجربة الفورية أو «اللعب التعاوني أونلاين» لدعوة صديق برمز الغرفة
      </div>
    </div>
  );
};
