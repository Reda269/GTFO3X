import React from 'react';

interface TassiliFrameProps {
  children: React.ReactNode;
  scanlines?: boolean;
}

export const TassiliFrame: React.FC<TassiliFrameProps> = ({ children, scanlines = false }) => {
  return (
    <div className="relative w-screen h-screen bg-[#06070c] flex items-center justify-center p-2 sm:p-4 overflow-hidden select-none">
      {/* Subtle outer subterranean ambient vignette */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 50%, rgba(28, 34, 52, 0.28) 0%, rgba(5, 6, 10, 0.96) 80%)',
        }}
      />

      {/* Fullscreen authentic Tassili ornamental stone frame */}
      <div className="relative w-full h-full max-w-[1600px] max-h-[960px] bg-[#080a10] border-2 border-[#3b3329] tassili-frame overflow-hidden flex flex-col">
        {/* Corner Tassili carved geometric brackets */}
        <svg className="pointer-events-none absolute top-2 right-2 w-8 h-8 text-[#c98838]/70 z-30" viewBox="0 0 32 32" fill="none">
          <path d="M2 2H30V6H6V30H2V2Z" fill="currentColor" />
          <rect x="10" y="10" width="5" height="5" fill="#60cde6" fillOpacity="0.6" />
        </svg>
        <svg className="pointer-events-none absolute top-2 left-2 w-8 h-8 text-[#c98838]/70 z-30 -scale-x-100" viewBox="0 0 32 32" fill="none">
          <path d="M2 2H30V6H6V30H2V2Z" fill="currentColor" />
          <rect x="10" y="10" width="5" height="5" fill="#60cde6" fillOpacity="0.6" />
        </svg>
        <svg className="pointer-events-none absolute bottom-2 right-2 w-8 h-8 text-[#c98838]/70 z-30 -scale-y-100" viewBox="0 0 32 32" fill="none">
          <path d="M2 2H30V6H6V30H2V2Z" fill="currentColor" />
          <rect x="10" y="10" width="5" height="5" fill="#60cde6" fillOpacity="0.6" />
        </svg>
        <svg className="pointer-events-none absolute bottom-2 left-2 w-8 h-8 text-[#c98838]/70 z-30 -scale-x-100 -scale-y-100" viewBox="0 0 32 32" fill="none">
          <path d="M2 2H30V6H6V30H2V2Z" fill="currentColor" />
          <rect x="10" y="10" width="5" height="5" fill="#60cde6" fillOpacity="0.6" />
        </svg>

        {/* Main viewport content */}
        <div className="relative flex-1 w-full h-full overflow-hidden">
          {children}
          {scanlines && <div className="scanlines-overlay absolute inset-0 z-20" />}
        </div>
      </div>
    </div>
  );
};
